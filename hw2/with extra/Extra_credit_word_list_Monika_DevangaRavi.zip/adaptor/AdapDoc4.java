fileTrailer

protected int	LWFTAdaptor.extractRecords(ChunkReceiver eq, long buffOffsetInFile, byte[] buf)
Extract records from a byte sequence
protected int	FileTailingAdaptorPreserveLines.extractRecords(ChunkReceiver eq, long buffOffsetInFile, byte[] buf) 
protected int	CharFileTailingAdaptorUTF8NewLineEscaped.extractRecords(ChunkReceiver eq, long buffOffsetInFile, byte[] buf)
Note: this method uses a temporary ArrayList (shared across instances).
protected int	CharFileTailingAdaptorUTF8.extractRecords(ChunkReceiver eq, long buffOffsetInFile, byte[] buf)
Note: this method uses a temporary ArrayList (shared across instances).
